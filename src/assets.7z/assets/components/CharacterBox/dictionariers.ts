export function getCharacterUpperDictionary(){
    const dictionary = new Map([['className', 'Class'], ['heritageAncestryName', 'Heritage'], ['size', 'Size'], ['backgroundName', 'Background']]);
    return dictionary;
}